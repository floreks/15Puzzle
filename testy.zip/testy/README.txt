Testy były generowane na chama brute forcem. Zdarzają się cykle i z tego powodu istnieją krótsze rozwiązania niż te wygenerowane.
